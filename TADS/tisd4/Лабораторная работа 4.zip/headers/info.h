#include "constants.h"
#include "data_structures.h"
#include "list_stack.h"
#include "array_stack.h"

void print_welcome_info();
int input_available_size(int *capacity);
int time_counting();