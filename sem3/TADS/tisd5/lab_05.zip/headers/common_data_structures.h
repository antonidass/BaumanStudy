


#ifndef COMMON_DATA_S
#define COMMON_DATA_S

typedef struct 
{
    double time;
    int type_service;
} task_t;

#endif