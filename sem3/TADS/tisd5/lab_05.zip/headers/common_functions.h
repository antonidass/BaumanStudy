#include "constants.h"





uint64_t tick(void);
int comparison_queue();

int handle_array_queue();

int handle_list_queue();