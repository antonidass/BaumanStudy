#include "constants.h"
#include "common_data_structures.h"
#include "list_queue.h"



void handle_list_service();

task_t generate_task(int type_service);

